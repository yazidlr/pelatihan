/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package enkapsulasi;

/**
 *
 * @author Bagoes
 */
public class kalkulator {
 int bil1;
 int bil2;
 public kalkulator(){
     this.bil1=bil1;
     this.bil2=bil2;
 }
 int perkalian(){
     return bil1*bil2;
 }
 double pembagian(){
     return bil1/bil2;
 }
 int penjumlahan(){
     return bil1+bil2;
 }
 int pengurangan(){
     return bil1-bil2;
 }
}   
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo1;

/**
 *
 * @author Bagoes
 */
public class lingkaran {
int r;

    public lingkaran() {
    this.r=r;
    }
    double luas(int r){
       return Math.PI*Math.pow(r, 2);
    }
    double keliling(int r){
       return (2*(Math.PI*r));
    }
}
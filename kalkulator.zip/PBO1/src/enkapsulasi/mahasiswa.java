/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package enkapsulasi;

/**
 *
 * @author Bagoes
 */
public class mahasiswa {
    private String nama;
    
    public mahasiswa(){    
    }
    
    public void setNama(String nama){
        this.nama=nama;
    }
    
    public String getNama(){
        return this.nama;
    }
}
